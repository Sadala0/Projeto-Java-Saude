package saude;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;

public class Clinica {
    private ArrayList<Paciente> pacientes = new ArrayList<>();
    private ArrayList<Medico> medicos = new ArrayList<>();
    private ArrayList<Sala> salas = new ArrayList<>();
    private ArrayList<Consulta> consultas = new ArrayList<>();
    private FilaEspera fila = new FilaEspera();

    public void cadastrarPaciente(Paciente p) {
        pacientes.add(p);
    }

    public void cadastrarMedico(Medico m) {
        medicos.add(m);
    }

    public void cadastrarSala(Sala s) {
        salas.add(s);
    }

    public Paciente buscarPaciente(int id) {
        for (Paciente p : pacientes) {
            if (p.getId() == id) return p;
        }
        return null;
    }

    public Medico buscarMedico(int id) {
        for (Medico m : medicos) {
            if (m.getId() == id) return m;
        }
        return null;
    }

    public Sala buscarSala(int id) {
        for (Sala s : salas) {
            if (s.getId() == id) return s;
        }
        return null;
    }

    public Consulta buscarConsulta(int id) {
        for (Consulta c : consultas) {
            if (c.getId() == id) return c;
        }
        return null;
    }

    // Regra 1: médico precisa estar disponível.
    // Regra 2: paciente não pode ter outra consulta no mesmo horário.
    // Regra 3: médico não pode ter outra consulta no mesmo horário.
    // Regra 4: sala não pode ter outra consulta no mesmo horário.
    public void agendar(int id, int pacienteId, int medicoId, int salaId, LocalDateTime data) {
        Paciente p = buscarPaciente(pacienteId);
        Medico m = buscarMedico(medicoId);
        Sala s = buscarSala(salaId);

        if (p == null || m == null || s == null)
            throw new IllegalArgumentException("Paciente, médico ou sala não encontrado.");

        if (!p.isAtivo())
            throw new IllegalStateException("Paciente está inativo.");

        if (!m.isDisponivel())
            throw new IllegalStateException("Médico indisponível.");

        for (Consulta c : consultas) {
            if (!c.getStatus().equals("CANCELADA") && c.getDataHora().equals(data)) {
                if (c.getPaciente().getId() == pacienteId)
                    throw new IllegalStateException("Paciente já possui consulta nesse horário.");
                if (c.getMedico().getId() == medicoId)
                    throw new IllegalStateException("Médico já possui consulta nesse horário.");
                if (c.getSala().getId() == salaId)
                    throw new IllegalStateException("Sala já possui consulta nesse horário.");
            }
        }

        Consulta consulta = new Consulta(id, p, m, s, data);
        consultas.add(consulta);
        p.adicionarConsulta(consulta);
    }

    public void editarPaciente(int id, String nome, int idade) {
        Paciente p = buscarPaciente(id);
        if (p == null) throw new IllegalArgumentException("Paciente não encontrado.");
        p.setNome(nome);
        p.setIdade(idade);
    }

    public void desativarPaciente(int id) {
        Paciente p = buscarPaciente(id);
        if (p == null) throw new IllegalArgumentException("Paciente não encontrado.");
        p.desativar();
    }

    public void concluirConsulta(int id) {
        Consulta c = buscarConsulta(id);
        if (c == null) throw new IllegalArgumentException("Consulta não encontrada.");
        if (!c.getStatus().equals("AGENDADA"))
            throw new IllegalStateException("Consulta não está agendada.");
        c.concluir();
    }

    public void cancelarConsulta(int id) {
        Consulta c = buscarConsulta(id);
        if (c == null) throw new IllegalArgumentException("Consulta não encontrada.");
        if (c.getStatus().equals("REALIZADA"))
            throw new IllegalStateException("Consulta já realizada.");
        c.cancelar();
    }

    // Regra 5: paciente só entra uma vez na fila.
    public void entrarNaFila(int pacienteId) {
        Paciente p = buscarPaciente(pacienteId);
        if (p == null) throw new IllegalArgumentException("Paciente não encontrado.");
        if (!p.isAtivo()) throw new IllegalStateException("Paciente inativo.");
        fila.entrar(p);
    }

    public void atenderFila() {
        fila.atenderPrimeiro();
    }

    public ArrayList<Paciente> pesquisarPaciente(String nome) {
        ArrayList<Paciente> resultado = new ArrayList<>();
        for (Paciente p : pacientes) {
            if (p.getNome().toLowerCase().contains(nome.toLowerCase())) {
                resultado.add(p);
            }
        }
        resultado.sort(Comparator.comparing(Paciente::getNome));
        return resultado;
    }

    public ArrayList<Consulta> consultasOrdenadas() {
        ArrayList<Consulta> lista = new ArrayList<>(consultas);
        lista.sort(Comparator.comparing(Consulta::getDataHora));
        return lista;
    }

    public double mediaIdade() {
        if (pacientes.isEmpty()) return 0;
        int total = 0;
        for (Paciente p : pacientes) total += p.getIdade();
        return (double) total / pacientes.size();
    }

    public int totalConsultas() {
        return consultas.size();
    }

    public int maiorIdade() {
        if (pacientes.isEmpty()) return 0;
        return pacientes.stream().mapToInt(Paciente::getIdade).max().orElse(0);
    }

    public ArrayList<Medico> rankingMedicos() {
        ArrayList<Medico> ranking = new ArrayList<>(medicos);
        ranking.sort((a, b) -> Integer.compare(contarConsultas(b), contarConsultas(a)));
        return ranking;
    }

    private int contarConsultas(Medico medico) {
        int total = 0;
        for (Consulta c : consultas) {
            if (c.getMedico().getId() == medico.getId()) total++;
        }
        return total;
    }

    // Indicador próprio: quantidade de pessoas aguardando.
    public int pessoasNaFila() {
        return fila.tamanho();
    }

    public ArrayList<Paciente> getPacientes() { return pacientes; }
    public ArrayList<Medico> getMedicos() { return medicos; }
    public ArrayList<Sala> getSalas() { return salas; }
    public ArrayList<Consulta> getConsultas() { return consultas; }
    public FilaEspera getFila() { return fila; }
}
