package saude;

import java.sql.*;

public class Banco {
    private static final String URL = "jdbc:h2:./data/saude";

    public static void salvarPaciente(Paciente p) {
        try (Connection c = DriverManager.getConnection(URL, "sa", "");
             Statement st = c.createStatement()) {

            st.executeUpdate("CREATE TABLE IF NOT EXISTS paciente (" +
                    "id INT PRIMARY KEY, nome VARCHAR(100), idade INT, ativo BOOLEAN)");

            PreparedStatement ps = c.prepareStatement(
                    "MERGE INTO paciente KEY(id) VALUES (?, ?, ?, ?)");
            ps.setInt(1, p.getId());
            ps.setString(2, p.getNome());
            ps.setInt(3, p.getIdade());
            ps.setBoolean(4, p.isAtivo());
            ps.executeUpdate();

            System.out.println("Paciente salvo no banco H2.");
        } catch (SQLException e) {
            System.out.println("Erro no banco: " + e.getMessage());
        }
    }
}
