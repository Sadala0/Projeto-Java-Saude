package saude;

public class Medico {
    private int id;
    private String nome;
    private String especialidade;
    private boolean disponivel;

    public Medico(int id, String nome, String especialidade) {
        this.id = id;
        this.nome = nome;
        this.especialidade = especialidade;
        this.disponivel = true;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getEspecialidade() { return especialidade; }
    public boolean isDisponivel() { return disponivel; }

    public void setNome(String nome) { this.nome = nome; }
    public void setEspecialidade(String especialidade) { this.especialidade = especialidade; }
    public void setDisponivel(boolean disponivel) { this.disponivel = disponivel; }

    @Override
    public String toString() {
        return id + " - " + nome + " | " + especialidade
                + " | " + (disponivel ? "DISPONÍVEL" : "INDISPONÍVEL");
    }
}
