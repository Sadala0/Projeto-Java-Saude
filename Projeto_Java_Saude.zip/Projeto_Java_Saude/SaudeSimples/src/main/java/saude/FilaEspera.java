package saude;

import java.util.ArrayList;

public class FilaEspera {
    private ArrayList<Paciente> pacientes = new ArrayList<>();

    public void entrar(Paciente paciente) {
        if (!pacientes.contains(paciente)) {
            pacientes.add(paciente);
        }
    }

    public void atenderPrimeiro() {
        if (!pacientes.isEmpty()) {
            pacientes.remove(0);
        }
    }

    public int tamanho() {
        return pacientes.size();
    }

    public ArrayList<Paciente> getPacientes() {
        return pacientes;
    }
}
