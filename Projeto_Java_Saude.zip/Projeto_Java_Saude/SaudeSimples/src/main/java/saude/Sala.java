package saude;

public class Sala {
    private int id;
    private String nome;
    private boolean disponivel;

    public Sala(int id, String nome) {
        this.id = id;
        this.nome = nome;
        this.disponivel = true;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public boolean isDisponivel() { return disponivel; }
    public void setDisponivel(boolean disponivel) { this.disponivel = disponivel; }

    @Override
    public String toString() {
        return id + " - " + nome + " | " + (disponivel ? "DISPONÍVEL" : "INDISPONÍVEL");
    }
}
