package saude;

import java.util.ArrayList;

public class Paciente {
    private int id;
    private String nome;
    private int idade;
    private boolean ativo;
    private ArrayList<Consulta> consultas = new ArrayList<>();

    public Paciente(int id, String nome, int idade) {
        this.id = id;
        this.nome = nome;
        this.idade = idade;
        this.ativo = true;
    }

    public void adicionarConsulta(Consulta consulta) {
        consultas.add(consulta);
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public int getIdade() { return idade; }
    public boolean isAtivo() { return ativo; }
    public ArrayList<Consulta> getConsultas() { return consultas; }

    public void setNome(String nome) { this.nome = nome; }
    public void setIdade(int idade) { this.idade = idade; }
    public void desativar() { ativo = false; }

    @Override
    public String toString() {
        return id + " - " + nome + " | idade: " + idade
                + " | " + (ativo ? "ATIVO" : "INATIVO");
    }
}
