package saude;

import java.time.LocalDateTime;

public class Consulta {
    private int id;
    private Paciente paciente;
    private Medico medico;
    private Sala sala;
    private LocalDateTime dataHora;
    private String status;

    public Consulta(int id, Paciente paciente, Medico medico, Sala sala, LocalDateTime dataHora) {
        this.id = id;
        this.paciente = paciente;
        this.medico = medico;
        this.sala = sala;
        this.dataHora = dataHora;
        this.status = "AGENDADA";
    }

    public void concluir() {
        status = "REALIZADA";
    }

    public void cancelar() {
        status = "CANCELADA";
    }

    public int getId() { return id; }
    public Paciente getPaciente() { return paciente; }
    public Medico getMedico() { return medico; }
    public Sala getSala() { return sala; }
    public LocalDateTime getDataHora() { return dataHora; }
    public String getStatus() { return status; }

    @Override
    public String toString() {
        return id + " | Paciente: " + paciente.getNome()
                + " | Médico: " + medico.getNome()
                + " | Sala: " + sala.getNome()
                + " | " + dataHora
                + " | " + status;
    }
}
