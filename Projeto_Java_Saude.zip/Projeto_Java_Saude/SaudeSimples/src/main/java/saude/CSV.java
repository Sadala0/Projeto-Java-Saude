package saude;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class CSV {
    public static void exportar(Clinica clinica) {
        try {
            Files.createDirectories(Path.of("data"));

            try (FileWriter arquivo = new FileWriter("data/pacientes.csv")) {
                arquivo.write("id,nome,idade,ativo\n");

                for (Paciente p : clinica.getPacientes()) {
                    arquivo.write(p.getId() + "," + p.getNome() + ","
                            + p.getIdade() + "," + p.isAtivo() + "\n");
                }
            }

            System.out.println("Arquivo data/pacientes.csv criado.");
        } catch (IOException e) {
            System.out.println("Erro ao criar CSV: " + e.getMessage());
        }
    }
}
