package saude;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {
    private static Scanner entrada = new Scanner(System.in);
    private static Clinica clinica = new Clinica();
    private static DateTimeFormatter formato =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public static void main(String[] args) {
        int opcao;

        do {
            System.out.println("\n===== SAÚDE SIMPLES =====");
            System.out.println("1 - Cadastrar paciente");
            System.out.println("2 - Listar pacientes");
            System.out.println("3 - Pesquisar paciente");
            System.out.println("4 - Editar paciente");
            System.out.println("5 - Desativar paciente");
            System.out.println("6 - Cadastrar médico");
            System.out.println("7 - Cadastrar sala");
            System.out.println("8 - Agendar consulta");
            System.out.println("9 - Listar consultas");
            System.out.println("10 - Concluir consulta");
            System.out.println("11 - Cancelar consulta");
            System.out.println("12 - Entrar na fila");
            System.out.println("13 - Atender fila");
            System.out.println("14 - Indicadores");
            System.out.println("15 - Exportar CSV");
            System.out.println("16 - Salvar paciente no H2");
            System.out.println("0 - Sair");

            opcao = lerInt("Escolha: ");

            try {
                switch (opcao) {
                    case 1 -> {
                        int id = lerInt("ID: ");
                        String nome = ler("Nome: ");
                        int idade = lerInt("Idade: ");
                        clinica.cadastrarPaciente(new Paciente(id, nome, idade));
                        System.out.println("Paciente cadastrado.");
                    }
                    case 2 -> clinica.getPacientes().forEach(System.out::println);
                    case 3 -> {
                        String nome = ler("Nome para pesquisar: ");
                        clinica.pesquisarPaciente(nome).forEach(System.out::println);
                    }
                    case 4 -> {
                        int id = lerInt("ID: ");
                        String nome = ler("Novo nome: ");
                        int idade = lerInt("Nova idade: ");
                        clinica.editarPaciente(id, nome, idade);
                        System.out.println("Paciente editado.");
                    }
                    case 5 -> {
                        clinica.desativarPaciente(lerInt("ID: "));
                        System.out.println("Paciente desativado.");
                    }
                    case 6 -> {
                        int id = lerInt("ID: ");
                        String nome = ler("Nome: ");
                        String esp = ler("Especialidade: ");
                        clinica.cadastrarMedico(new Medico(id, nome, esp));
                        System.out.println("Médico cadastrado.");
                    }
                    case 7 -> {
                        int id = lerInt("ID: ");
                        String nome = ler("Nome da sala: ");
                        clinica.cadastrarSala(new Sala(id, nome));
                        System.out.println("Sala cadastrada.");
                    }
                    case 8 -> {
                        int id = lerInt("ID da consulta: ");
                        int paciente = lerInt("ID do paciente: ");
                        int medico = lerInt("ID do médico: ");
                        int sala = lerInt("ID da sala: ");
                        String texto = ler("Data/hora (dd/MM/yyyy HH:mm): ");
                        LocalDateTime data = LocalDateTime.parse(texto, formato);

                        clinica.agendar(id, paciente, medico, sala, data);
                        System.out.println("Consulta agendada.");
                    }
                    case 9 -> clinica.consultasOrdenadas().forEach(System.out::println);
                    case 10 -> {
                        clinica.concluirConsulta(lerInt("ID da consulta: "));
                        System.out.println("Consulta realizada.");
                    }
                    case 11 -> {
                        clinica.cancelarConsulta(lerInt("ID da consulta: "));
                        System.out.println("Consulta cancelada.");
                    }
                    case 12 -> {
                        clinica.entrarNaFila(lerInt("ID do paciente: "));
                        System.out.println("Paciente colocado na fila.");
                    }
                    case 13 -> {
                        clinica.atenderFila();
                        System.out.println("Primeiro paciente atendido.");
                    }
                    case 14 -> {
                        System.out.println("Média de idade: " +
                                String.format("%.2f", clinica.mediaIdade()));
                        System.out.println("Total de consultas: " +
                                clinica.totalConsultas());

                        System.out.println("Maior idade dos pacientes: " +
                                clinica.maiorIdade() + " anos");

                        System.out.println("Ranking de médicos:");
                        int posicao = 1;
                        for (Medico m : clinica.rankingMedicos()) {
                            System.out.println(posicao++ + "º - " + m.getNome());
                        }

                        System.out.println("Pessoas na fila: " +
                                clinica.pessoasNaFila());
                    }
                    case 15 -> CSV.exportar(clinica);
                    case 16 -> {
                        Paciente p = clinica.buscarPaciente(lerInt("ID do paciente: "));
                        if (p == null) throw new IllegalArgumentException("Paciente não encontrado.");
                        Banco.salvarPaciente(p);
                    }
                    case 0 -> System.out.println("Fim.");
                    default -> System.out.println("Opção inválida.");
                }
            } catch (RuntimeException e) {
                System.out.println("ERRO: " + e.getMessage());
            }
        } while (opcao != 0);
    }

    private static int lerInt(String mensagem) {
        return Integer.parseInt(ler(mensagem));
    }

    private static String ler(String mensagem) {
        System.out.print(mensagem);
        return entrada.nextLine();
    }
}
