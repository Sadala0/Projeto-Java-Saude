package saude;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class ClinicaTest {

    @Test
    void naoPodeTerDuasConsultasNoMesmoHorario() {
        Clinica c = new Clinica();

        c.cadastrarPaciente(new Paciente(1, "Ana", 20));
        c.cadastrarMedico(new Medico(1, "Dr. João", "Clínico"));
        c.cadastrarSala(new Sala(1, "Sala 1"));

        LocalDateTime data = LocalDateTime.of(2026, 10, 10, 10, 0);

        c.agendar(1, 1, 1, 1, data);

        // O mesmo médico não pode ter outra consulta no mesmo horário.
        assertThrows(IllegalStateException.class, () ->
                c.agendar(2, 1, 1, 1, data));
    }
}
