# Saúde Simples

## Problema

Clínicas e hospitais podem ter salas de espera cheias, marcações duplicadas e dificuldade para controlar quais médicos estão disponíveis.

O sistema **Saúde** foi criado para resolver uma parte desse problema por meio de um programa Java simples de terminal. Ele permite cadastrar pacientes, médicos e salas, controlar consultas e fila de espera e mostrar indicadores básicos.

Fonte do problema utilizada:
https://revistamaster.emnuvens.com.br/RM/article/download/802/385

## Usuários

- Recepcionista
- Secretário(a)
- Administrador da clínica

## Funcionalidades

- Cadastrar paciente.
- Consultar/listar pacientes.
- Pesquisar paciente pelo nome.
- Editar paciente.
- Desativar paciente.
- Cadastrar médico.
- Cadastrar sala.
- Agendar consulta.
- Listar consultas em ordem de data.
- Concluir ou cancelar consulta.
- Colocar paciente na fila de espera.
- Atender o primeiro da fila.
- Mostrar indicadores.
- Exportar pacientes para CSV.
- Salvar paciente em banco H2.

## Classes

1. `Paciente`
2. `Medico`
3. `Sala`
4. `Consulta`
5. `FilaEspera`
6. `Clinica`

Classes auxiliares:
- `Main`
- `Banco`
- `CSV`

## Relacionamentos

- `Clinica` possui vários pacientes, médicos, salas e consultas.
- `FilaEspera` possui vários pacientes.
- `Paciente` possui várias consultas.
- `Consulta` possui um paciente, um médico e uma sala.

Assim, existem coleções em mais de uma classe e associação entre vários objetos.

## Regras de negócio

1. Médico indisponível não pode receber novas consultas.
2. Paciente inativo não pode receber novas consultas.
3. O mesmo paciente não pode ter duas consultas no mesmo horário.
4. O mesmo médico não pode ter duas consultas no mesmo horário.
5. A mesma sala não pode ter duas consultas no mesmo horário.
6. Um paciente não entra duas vezes na fila de espera.
7. Consulta realizada não pode ser cancelada.
8. Ao realizar ou cancelar uma consulta, a sala volta a ficar livre.

## Funcionalidade principal

O fluxo principal é:

**Paciente → Médico disponível → Sala livre → Agendamento → Consulta → Realização/Cancelamento**

A fila de espera é usada quando há necessidade de organizar pacientes aguardando atendimento.

## Relatórios e indicadores

O sistema possui os cinco tipos pedidos:

- **Média:** média de idade dos pacientes.
- **Total:** total de consultas cadastradas.
- **Maior/menor:** maior idade entre os pacientes cadastrados.
- **Ranking:** médicos com mais consultas.
- **Indicador próprio:** quantidade de pessoas na fila de espera.

## Tecnologias

- Java 21
- Maven
- H2 Database
- JUnit 5
- CSV

As duas funcionalidades externas são:
1. Banco de dados H2.
2. Exportação de dados para CSV.

## Como executar

1. Instale o JDK 21 (por exemplo, 21.0.12.1).
2. Abra o projeto no VS Code.
3. No terminal, execute:

```bash
mvn test
```

Depois:

```bash
mvn compile
```

Execute a classe:

```text
saude.Main
```

## Exemplo

Cadastre:
- paciente: Ana
- médico: João / Clínica Geral
- sala: Sala 1

Depois agende uma consulta para `10/10/2026 10:00`.

Se tentar marcar outra consulta para o mesmo médico no mesmo horário, o sistema recusará o agendamento.

## Uso de IA

| Ferramenta | Objetivo | Resumo do uso | Revisão pelo Dev |
|---|---|---|---|
| Claude | Código base | Auxiliou na criação da estrutura simples, classes, regras de negócio e menu  | Código e regras foram testados e revisados pelo integrante. |

